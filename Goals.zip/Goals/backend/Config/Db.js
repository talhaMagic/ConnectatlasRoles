const mongoose = require("mongoose");

async function DBconnection(){

    const connections = await mongoose.connect(process.env.DB)

    if(connections) console.log("Mongo db Atlas is connected");

}

module.exports = {DBconnection}