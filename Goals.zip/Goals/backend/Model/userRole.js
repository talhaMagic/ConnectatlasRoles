
const mongoose = require("mongoose");

const userRole_Model = mongoose.Schema(

    {

    RoleName:{
        type:String,
        required:[true, "Role name must enter"],
        
    },

    status:{
        type:String,
        required:[true, "status must there"]
    }

    }

)

module.exports = mongoose.model("Roles",userRole_Model)