const express = require("express");

const app = express();

require("dotenv").config();

//connectionDB


//model

const {Roles} = require("./Model/userRole")

const {DBconnection} = require("./Config/Db");

app.listen(process.env.PORT, function() {
    console.log(`Server is running on PORT ${process.env.PORT}`);
    DBconnection();
});
